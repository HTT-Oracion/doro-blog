module.exports = {
    devServer: {
        port: 5000
    }
}